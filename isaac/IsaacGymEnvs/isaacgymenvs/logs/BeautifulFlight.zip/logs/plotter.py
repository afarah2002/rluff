import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import time
df = pd.read_csv('alphas.csv')

plt.figure();
df.plot()

# plt.xlim([0,100])

#%%

df = pd.read_csv('state_global.csv')
print(df.head())
raw_state_global = df.to_numpy()

df = pd.read_csv('as.csv')
raw_air_speed = df.to_numpy()
print(df.head())

df = pd.read_csv('gs.csv')
raw_ground_speed = df.to_numpy()
print(df.head())

    
total_gliders = np.int(np.max(raw_state_global[:,0]))+1
curr_glider = 1

plt.figure()
for curr_glider in range(1,total_gliders+1):
    # plt.figure()
    # plt.plot(raw_state_global[curr_glider-1::total_gliders,1])
    # plt.plot(raw_state_global[curr_glider-1::total_gliders,2])
    # plt.plot(raw_state_global[curr_glider-1::total_gliders,3])
    # plt.legend(['px', 'py', 'pz'])
    # plt.grid(True)
    # plt.show()
    
    # plt.figure()
    # plt.plot(raw_state_global[curr_glider-1::total_gliders,3])
    # plt.grid(True)
    # plt.show()
    
    # plt.figure()
    # plt.plot(raw_state_global[curr_glider-1::total_gliders,4])
    # plt.plot(raw_state_global[curr_glider-1::total_gliders,5])
    # plt.plot(raw_state_global[curr_glider-1::total_gliders,6])
    # plt.legend(['vx', 'vy', 'vz'])
    # plt.grid(True)
    # plt.show()
    
    # plt.figure()
    # plt.plot(raw_state_global[curr_glider-1::total_gliders,7])
    # plt.plot(raw_state_global[curr_glider-1::total_gliders,8])
    # plt.plot(raw_state_global[curr_glider-1::total_gliders,9])ax = plt.axes(projection='3d')
    # Data for a three-dimensional line

    # plt.legend(['wx', 'wy', 'wz'])
    # plt.grid(True)
    # plt.show()
    
    plt.plot(raw_ground_speed[curr_glider-1::total_gliders,1], raw_air_speed[curr_glider-1::total_gliders,1])
    plt.grid(True)
    plt.xlabel('ground_speed')
    plt.ylabel('air_speed')
plt.show()


#%%

df = pd.read_csv('rk4_euler_angs.csv')
print(df.head())
df = pd.read_csv('rk4_lv_loc.csv')
print(df.head())
df = pd.read_csv('rk4_av_loc.csv')
print(df.head())


#%%
curr_glider = 1

ax = plt.axes(projection='3d')
# Data for a three-dimensional line

x_raw = raw_state_global[curr_glider-1::total_gliders,1]
y_raw = raw_state_global[curr_glider-1::total_gliders,2]
z_raw = raw_state_global[curr_glider-1::total_gliders,3]
gs_raw = raw_ground_speed[curr_glider-1::total_gliders,1]
as_raw = raw_air_speed[curr_glider-1::total_gliders,1]


data_resets = np.where(np.abs(np.diff(raw_state_global[curr_glider-1::total_gliders,1])) > 1)[0]

data_start = 1
for i in range(len(data_resets)):
    data_end = data_resets[i]
    print('Start')
    print(data_start)
    print('End')
    print(data_end)
    x_data = x_raw[data_start:data_end]
    y_data = y_raw[data_start:data_end]
    z_data = z_raw[data_start:data_end]
    gs_data = gs_raw[data_start:data_end]
    as_data = as_raw[data_start:data_end]
    
    data_pts = len(z_data)
    
    G = 9.81
    E = G*z_data + 0.5*gs_data**2

    
    plt.figure("My Fig", figsize=(10, 10), dpi=80)
    ax = plt.axes(projection='3d')
    ax.view_init(45, 90)
    # ax.plot3D(x_data, y_data, z_data)
    ax.scatter(x_data, y_data, z_data, s=1, c = plt.cm.jet(E/max(E))) 
    plt.title('Aircraft Position')
    ax.set_xlabel('X (m)')
    ax.set_ylabel('Y (m)')
    ax.set_zlabel('Z (m)')
    plt.show()
    data_start = data_end + 1
    
    # plt.figure('AirSpeed GroundSpeed')
    # plt.plot(raw_ground_speed[curr_glider-1::total_gliders,1], raw_air_speed[curr_glider-1::total_gliders,1])
    # plt.grid(True)
    # plt.xlabel('ground_speed')
    # plt.ylabel('air_speed')

#%%
data_start = 1+15700
data_end = data_resets[0]-98000
print('Start')
print(data_start)
print('End')
print(data_end)
x_data = x_raw[data_start:data_end]
y_data = y_raw[data_start:data_end]
z_data = z_raw[data_start:data_end]
gs_data = gs_raw[data_start:data_end]
as_data = as_raw[data_start:data_end]

data_pts = len(z_data)

G = 9.81
E = G*z_data + 0.5*gs_data**2


plt.figure("My Fig", figsize=(10, 10), dpi=300)
ax = plt.axes(projection='3d')
ax.view_init(45, 45)
# ax.plot3D(x_data, y_data, z_data)
ax.scatter(x_data, y_data, z_data, s=1, c = plt.cm.jet(E/max(E))) 
plt.title('Aircraft Position')
ax.set_xlabel('X (m)')
ax.set_ylabel('Y (m)')
ax.set_zlabel('Z (m)')
ax.set(xlim=(min(x_data), max(x_data)))
ax.set(ylim=(np.mean(y_data)-(max(x_data)-min(x_data))/2, np.mean(y_data)+(max(x_data)-min(x_data))/2))
plt.show()

# plt.figure('AirSpeed GroundSpeed', figsize=(10, 10), dpi=100)
# plt.plot(gs_data, as_data)
# plt.grid(True)
# plt.title('Ground Speed vs. Air Speed')
# plt.xlabel('ground_speed')
# plt.ylabel('air_speed')

#%%
plt.figure('EnergyPlot', figsize=(10, 10), dpi=300)
ax = plt.axes()
ax.scatter(np.arange(0,len(E))/100, E, s=1, c = plt.cm.jet(E/max(E)))
plt.grid(True)
plt.title('Aircraft Energy')
ax.set_xlabel('Time (s)')
ax.set_ylabel('Scaled Energy')
plt.show()
#%%
data_start = 1
data_end = data_pts


G = 9.81
E = G*z_data + 0.5*gs_data**2


plt.figure("My Fig", figsize=(10, 10), dpi=80)
ax = plt.axes(projection='3d')
ax.view_init(0, 0)
# ax.plot3D(x_data, y_data, z_data)
ax.scatter(x_data, y_data, z_data, s=1, c = plt.cm.jet(E/max(E))) 
plt.title('Aircraft Position')
ax.set_xlabel('X (m)')
ax.set_ylabel('Y (m)')
ax.set_zlabel('Z (m)')
plt.show()
data_start = data_end + 1

#%%

ax = plt.axes(projection='3d')
# Data for a three-dimensional line


data_start = 1
data_end = 1000
ax.plot3D(gs_data, as_data, z_data, 'gray')
ax.view_init(35, -90)


for i in range(data_pts-1):
    ax.plot(x_data[i:i+2], y_data[i:i+2], z_data[i:i+2], color=plt.cm.jet(z_data[i]/max(z_data)))

#%%
import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import matplotlib.pyplot as plt

fig = plt.figure()
ax = plt.axes(projection='3d')
theta = np.linspace(-4 * np.pi, 4 * np.pi, 100)
z = np.linspace(-2, 2, 100)
r = z**2 + 1
x = r * np.sin(theta)
y = r * np.cos(theta)

#1 colored by value of `z`
ax.scatter(x, y, z, c = plt.cm.jet(z/max(z))) 

#2 colored by index (same in this example since z is a linspace too)

data_pts = len(z)
ax.scatter(x, y, z, c = plt.cm.jet(np.linspace(0,1,data_pts)))

for i in range(data_pts-1):
    ax.plot(x[i:i+2], y[i:i+2], z[i:i+2], color=plt.cm.jet(z[i]/max(z)))
#%%
